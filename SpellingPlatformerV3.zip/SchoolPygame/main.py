# Importing essential libraries (pygame, random, string, button)
import pygame
import math
import random
import string
from sys import exit
from button import Button
from maps import maps

pygame.init()

WIDTH, HEIGHT = 1200, 900
tile_size = WIDTH / 12

# Specifying window dimensions & name 
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Spelling Platformer")
clock = pygame.time.Clock()

# Font info
word_font = pygame.font.Font("fonts/vhs_gothic.ttf", 54)
info_font = pygame.font.Font("fonts/Daydream.ttf", 20)
coins_font = pygame.font.Font("fonts/04B_30__.ttf", 40)
words_spelt_font = pygame.font.Font("fonts/vhs_gothic.ttf", 30)
letter_font = pygame.font.Font("fonts/vhs_gothic.ttf", int(tile_size // 2))

# Loading images & converting them (making them more performant)

# Characters
duck = pygame.image.load("images/characters/duck.png").convert_alpha()
cat = pygame.image.load("images/characters/cat.png").convert_alpha()
zombie = pygame.image.load("images/characters/zombie.png").convert_alpha()

duck = pygame.transform.scale(duck, (duck.get_width() * 1.8, 90))
cat = pygame.transform.scale(cat, (cat.get_width() * 1.8, 90))
zombie = pygame.transform.scale(zombie, (zombie.get_width() * 2.6, 90))

# Map 1
sky = pygame.image.load("images/map-1/day-sky.jpg").convert()
dirt = pygame.image.load("images/map-1/dirt.png").convert()
grass = pygame.image.load("images/map-1/grass.png").convert()
grass_platform = pygame.image.load("images/map-1/grass-platform.png").convert_alpha()

# Map 2
desert_sky = pygame.image.load("images/map-2/desertSky.png").convert()
sand = pygame.image.load("images/map-2/sand.png").convert()
top_sand = pygame.image.load("images/map-2/top-sand.png").convert()
sand_platform = pygame.image.load("images/map-2/sand-platform.png").convert_alpha()

# Obstacles
spikes = pygame.image.load("images/other/spikes.png").convert_alpha()
cactus = pygame.image.load("images/other/cactus.png").convert_alpha()
coin = pygame.image.load("images/other/coin.png").convert_alpha()

# Player surface and rect
player_surf = duck
player_rect = player_surf.get_rect()

# Applying a transformation to scale each image appropriately
sky = pygame.transform.scale(sky, (WIDTH, HEIGHT))
grass = pygame.transform.scale(grass, (tile_size, tile_size))
dirt = pygame.transform.scale(dirt, (tile_size, tile_size))
grass_platform = pygame.transform.scale(grass_platform, (tile_size, grass_platform.get_height() * (tile_size / grass_platform.get_width())))

desert_sky = pygame.transform.scale(desert_sky, (WIDTH, HEIGHT))
top_sand = pygame.transform.scale(top_sand, (tile_size, tile_size))
sand = pygame.transform.scale(sand, (tile_size, tile_size))
sand_platform = pygame.transform.scale(sand_platform, (tile_size, sand_platform.get_height() * (tile_size / sand_platform.get_width())))

coin = pygame.transform.scale(coin, (tile_size / 2, tile_size/ 2))

# Obstacles
spikes = pygame.transform.scale(spikes, (tile_size * 0.75, tile_size / 2))
cactus = pygame.transform.scale(cactus, (tile_size * 0.6, tile_size * 0.75))

# Loading sound effects
jump_sfx = pygame.mixer.Sound("sounds/jump.mp3")
coin_sfx = pygame.mixer.Sound("sounds/coin-collected.wav")
letter_sfx = pygame.mixer.Sound("sounds/letter-collected.wav")
incorrect_sfx = pygame.mixer.Sound("sounds/incorrect.mp3")
bruh_sfx = pygame.mixer.Sound("sounds/dead.mp3")
word_spelt_sfx = pygame.mixer.Sound("sounds/word-spelled.mp3")
purchase_successful_sfx = pygame.mixer.Sound("sounds/purchase-successful.mp3")
music = pygame.mixer.Sound("sounds/music.mp3")

music.play(-1, 0, 1)

game_map = maps[random.randint(0, len(maps) - 1)]

# GAME VARIABLES
FPS = 60
word_difficulty = 1
game_duration = 90
elapsed_time = 0
ground_level = HEIGHT - WIDTH / 10
word = None
definition = None
correct_letter = None
character_num = 0
valid_positions = []
coin_counter = 0
words_spelt = 0
coin_size = 1
muted = False
diff = 0

running = True

# JUMPING VARIABLES
jump_power = 20 # Editable
gravity = 1     # Editable
y_velocity = 0
air_timer = 0

# PLAYER VARIABLES
speed = 6 # Editable

default_location = [tile_size * 1.5, ground_level - tile_size] # Editable
player_location = [WIDTH, 0]

moving_right = False
moving_left = False
y_velocity = 0
direction = "right"

tile_rects = []
coin_rects = []
letter_rects = []
obstacle_rects = []
particles = []
spelling_dict = {}

ground_layer = grass
base_layer = dirt
platform = grass_platform
obstacle = spikes

# Main menu functions

# bro this code is so bad

class Particle:
    def __init__(self, x, y, color=(255, 255, 255), size_range=(2, 5)):
        self.x = x
        self.y = y
        self.radius = random.uniform(size_range[0], size_range[1])
        self.color = color
        self.vel = [random.uniform(-2, 2), random.uniform(-2, -1)]
        self.life = 100

    def update(self):
        self.x += self.vel[0]
        self.y += self.vel[1]
        self.vel[1] += 0.05
        self.radius *= 0.97
        self.life -= 1

    def draw(self, surface):
        if self.radius > 0:
            pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), int(self.radius))

def spawn_particles(x, y, amount=10, color=(255, 255, 255), size_range=(2, 5)):
    for _ in range(amount):
        particles.append(Particle(x, y, color=color, size_range=size_range))

def get_font(size):
    return pygame.font.Font("fonts/Daydream.ttf", size)

def play():
    global elapsed_time
    global moving_right
    global moving_left
    global y_velocity
    global direction
    global player_rect
    global air_timer

    while True: # Game loop
        if elapsed_time >= game_duration:
            elapsed_time = 0
            end_screen()

        # Background
        screen.blit(sky, (0, 0))

        # Rendering all tiles using a tile map
        render_tiles()

        # Player movement & applying collision
        player_movement = [0, 0]
        if moving_right:
            player_movement[0] += speed
            spawn_particles(*player_rect.midbottom, 1, "lightyellow", (2, 3))
        if moving_left:
            player_movement[0] -= speed
            spawn_particles(*player_rect.midbottom, 1, "lightyellow", (2, 3))

        # Player gravity
        player_movement[1] += y_velocity
        y_velocity += gravity
        if y_velocity > 20:
            y_velocity = 20

        # Getting player_rect from collision function
        player_rect, collisions = move(player_rect, player_movement, tile_rects, )

        # If player falls out of map, place them at a default location
        if player_rect.y > HEIGHT:
            player_rect.midbottom = (default_location[0], default_location[1])
            bruh_sfx.play()

        # When top and bottom collisions are detected, set y_velocity
        if collisions["bottom"]:
            y_velocity = 1
            air_timer = 0
        else:
            air_timer += 1

        if collisions["top"]:
            y_velocity = 0

        # Checking for inputs
        for event in pygame.event.get():
            # If user requests to close window, exit pygame & quit program
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_RIGHT, pygame.K_d):
                    moving_right = True
                    direction = "right"
                if event.key in (pygame.K_LEFT, pygame.K_a):
                    moving_left = True
                    direction = "left"
                if event.key in (pygame.K_UP, pygame.K_w, pygame.K_SPACE):
                    # Jumping
                    if air_timer < 4:
                        y_velocity = -jump_power
                        jump_sfx.play()
                if event.key == pygame.K_ESCAPE:
                    main_menu()
                    break
            if event.type == pygame.KEYUP:
                if event.key in (pygame.K_RIGHT, pygame.K_d):
                    moving_right = False
                if event.key in (pygame.K_LEFT, pygame.K_a):
                    moving_left = False

        # Rendering the character (left and right)
        if direction == "right":
            screen.blit(player_surf, player_rect)
        elif direction == "left":
            screen.blit(pygame.transform.flip(player_surf, True, False), player_rect)

        # Text and font information
        fps_str = "FPS: {fps:.2f}"

        coordinate_text = info_font.render(f"X: {str(player_rect.x // 1)} Y: {str(int(player_rect.y))}", False, "white")
        coordinate_rect = coordinate_text.get_rect()
        coordinate_rect.bottomleft = (0, HEIGHT)

        framerate_text = info_font.render(fps_str.format(fps = clock.get_fps()), False, "white")
        framerate_rect = framerate_text.get_rect()
        framerate_rect.bottomleft = (0, HEIGHT - coordinate_rect.height)

        coins_text = coins_font.render(f"COINS: {coin_counter}", False, "Yellow")
        words_text = words_spelt_font.render(f"WORDS SPELT: {words_spelt}", False, "White")
        time_text = words_spelt_font.render(f"TIME LEFT: {math.ceil(game_duration - elapsed_time)}", False, "Green")


        # Rendering the word to spell
        render_word()

        # Rendering text (info & currency)
        for particle in particles[:]:
                particle.update()
                particle.draw(screen)
                if particle.life <= 0 or particle.radius <= 0:
                    particles.remove(particle)

        screen.blit(coordinate_text, coordinate_rect)
        screen.blit(framerate_text, framerate_rect)
        screen.blit(coins_text, (0, 0))
        screen.blit(words_text, (0, 45))
        screen.blit(time_text, (0, 90))

        # Updating the display
        pygame.display.update()
        dt = clock.tick(FPS) / 1000
        elapsed_time += dt

def options():
    global game_map
    global coin_counter
    global words_spelt
    global muted
    global diff
    global word_difficulty

    while True:
        screen.blit(sky, (0, 0))
        text = None

        OPTIONS_TEXT = get_font(80).render("OPTIONS", True, "orange")
        OPTIONS_RECT = OPTIONS_TEXT.get_rect(center=(WIDTH / 2, 100))

        if muted:
            text = "UNMUTE MUSIC"
        else:
            text = "MUTE MUSIC"

        difficulty_list = ["EASY", "MEDIUM", "HARD", "IMPOSSIBLE"]

        MENU_MOUSE_POS = pygame.mouse.get_pos()

        VOLUME_BUTTON = Button(image=None, pos=(WIDTH / 2, 400), 
                        text_input=text, font=get_font(60), base_color="#FFFFFF", hovering_color="grey90")
        DIFFICULTY_BUTTON = Button(image=None, pos=(WIDTH / 2, 500), 
                        text_input=difficulty_list[diff], font=get_font(60), base_color="#FFFFFF", hovering_color="grey90")
        BACK_TO_MENU_BUTTON = Button(image=None, pos=(WIDTH / 5, 800), 
                        text_input="BACK TO MENU", font=get_font(40), base_color="#FFFFFF", hovering_color="grey40")
        screen.blit(OPTIONS_TEXT, OPTIONS_RECT)

        for button in [VOLUME_BUTTON, DIFFICULTY_BUTTON, BACK_TO_MENU_BUTTON]:
            button.change_color(MENU_MOUSE_POS)
            button.update(screen)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if VOLUME_BUTTON.check_for_input(MENU_MOUSE_POS):
                    muted = not muted
                    if muted:
                        music.set_volume(0)
                    else:
                        music.set_volume(1)
                if DIFFICULTY_BUTTON.check_for_input(MENU_MOUSE_POS):
                    diff += 1
                    diff %= 4
                    
                    word_difficulty = diff * 2 + 2
                if BACK_TO_MENU_BUTTON.check_for_input(MENU_MOUSE_POS):
                    main_menu()
                    break

        pygame.display.update()

def main_menu():
    global game_map

    while True:
        screen.blit(sky, (0, 0))

        a = math.ceil(pygame.time.get_ticks()/ 3000) % 3
        b = math.ceil(pygame.time.get_ticks() / 1000) % 2

        change_biome(b)

        game_map = maps[a]

        render_tiles()

        MENU_MOUSE_POS = pygame.mouse.get_pos()

        MENU_TEXT = get_font(80).render("MAIN MENU", True, "#e0f000")
        MENU_RECT = MENU_TEXT.get_rect(center=(WIDTH / 2, 100))

        PLAY_BUTTON = Button(image=None, pos=(WIDTH / 2, 350), 
                            text_input="PLAY", font=get_font(60), base_color="#FFFFFF", hovering_color="grey90")
        OPTIONS_BUTTON = Button(image=None, pos=(WIDTH / 2, 500), 
                            text_input="SETTINGS", font=get_font(60), base_color="#FFFFFF", hovering_color="grey90")
        SHOP_BUTTON = Button(image=None, pos=(WIDTH / 2, 650), 
                            text_input="SHOP", font=get_font(60), base_color="#FFFFFF", hovering_color="grey90")

        screen.blit(MENU_TEXT, MENU_RECT)

        for button in [PLAY_BUTTON, OPTIONS_BUTTON, SHOP_BUTTON]:
            button.change_color(MENU_MOUSE_POS)
            button.update(screen)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.check_for_input(MENU_MOUSE_POS):
                    start_game()
                    play()
                if OPTIONS_BUTTON.check_for_input(MENU_MOUSE_POS):
                    options()
                if SHOP_BUTTON.check_for_input(MENU_MOUSE_POS):
                    shop()

        pygame.display.update()

def shop():
    global player_surf
    global coin_counter

    while True:
        screen.blit(sky, (0, 0))

        MENU_MOUSE_POS = pygame.mouse.get_pos()

        SHOP_TEXT = get_font(80).render("SHOP", True, "green")
        SHOP_RECT = SHOP_TEXT.get_rect(center=(WIDTH / 2, 100))

        BUY_CAT_BUTTON = Button(image=None, pos=(WIDTH / 4, 350), 
                        text_input="BUY CAT: 30 COINS", font=get_font(30), base_color="#FFFFFF", hovering_color="grey90")
        BUY_ZOMBIE_BUTTON = Button(image=None, pos=(WIDTH / 4 * 3, 350), 
                        text_input="BUY ZOMBIE: 50 COINS", font=get_font(30), base_color="#FFFFFF", hovering_color="grey90")
        BACK_TO_MENU_BUTTON = Button(image=None, pos=(WIDTH / 5, 800), 
                        text_input="BACK TO MENU", font=get_font(40), base_color="#FFFFFF", hovering_color="grey40")
        
        cat_center = cat.get_rect(center = (WIDTH / 4, 500))
        zombie_center = zombie.get_rect(center = (WIDTH / 4 * 3, 500))

        coins_collected_text = get_font(40).render(f"COINS COLLECTED: {coin_counter}", True, "Yellow")
        coins_collected_rect = coins_collected_text.get_rect(center = (WIDTH / 2, 200))

        screen.blit(coins_collected_text, coins_collected_rect)

        screen.blit(pygame.transform.scale_by(cat, 3), cat_center)
        screen.blit(pygame.transform.scale_by(zombie, 3), zombie_center)

        screen.blit(SHOP_TEXT, SHOP_RECT)

        for button in [BUY_CAT_BUTTON, BUY_ZOMBIE_BUTTON, BACK_TO_MENU_BUTTON]:
            button.change_color(MENU_MOUSE_POS)
            button.update(screen)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if BUY_CAT_BUTTON.check_for_input(MENU_MOUSE_POS):
                    if coin_counter >= 30:
                        player_surf = cat
                        coin_counter -= 30
                        purchase_successful_sfx.play()
                    else:
                        incorrect_sfx.play()
                if BUY_ZOMBIE_BUTTON.check_for_input(MENU_MOUSE_POS):
                    if coin_counter >= 50:
                        player_surf = zombie
                        coin_counter -= 50
                        purchase_successful_sfx.play()
                    else:
                        incorrect_sfx.play()
                if BACK_TO_MENU_BUTTON.check_for_input(MENU_MOUSE_POS):
                    main_menu()
                    break

        pygame.display.update()

def end_screen():
    global game_map
    global coin_counter
    global words_spelt

    while True:
        screen.blit(sky, (0, 0))

        MENU_MOUSE_POS = pygame.mouse.get_pos()

        MENU_TEXT = get_font(80).render("GAME OVER", True, "red")
        MENU_RECT = MENU_TEXT.get_rect(center=(WIDTH / 2, 100))

        PLAY_BUTTON = Button(image=None, pos=(WIDTH / 2, 400), 
                            text_input="PLAY", font=get_font(60), base_color="#FFFFFF", hovering_color="grey90")
        MENU_BUTTON = Button(image=None, pos=(WIDTH / 2, 550), 
                            text_input="BACK TO MENU", font=get_font(60), base_color="#FFFFFF", hovering_color="grey90")
        
        coins_collected_text = get_font(40).render(f"COINS COLLECTED: {coin_counter}", True, "Yellow")
        coins_collected_rect = coins_collected_text.get_rect(center = (WIDTH / 2, 200))

        words_spelt_text = get_font(40).render(f"WORDS SPELT: {words_spelt}", True, "white")
        words_spelt_rect = words_spelt_text.get_rect(center = (WIDTH / 2, 270))

        screen.blit(MENU_TEXT, MENU_RECT)
        screen.blit(coins_collected_text, coins_collected_rect)
        screen.blit(words_spelt_text, words_spelt_rect)

        for button in [PLAY_BUTTON, MENU_BUTTON]:
            button.change_color(MENU_MOUSE_POS)
            button.update(screen)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.check_for_input(MENU_MOUSE_POS):
                    y = 0
                    for row in game_map:
                        x = 0
                        for tile in row:
                            if tile.isalpha():
                                game_map[y][x] = "0"
                            x += 1
                        y += 1
                    words_spelt = 0
                    start_game()
                    play()

                    break
                if MENU_BUTTON.check_for_input(MENU_MOUSE_POS):
                    main_menu()

        pygame.display.update()

def collision_test(rect, tiles):
    hit_list = []
    
    for tile in tiles:
        if rect.colliderect(tile):
            hit_list.append(tile)

    return hit_list

def move(rect, movement, tiles):
    collision_types = {"top": False, "bottom": False, "right": False, "left": False}

    rect.x += movement[0]

    # x movement

    hit_list = collision_test(rect, tiles)
    for tile in hit_list:
        if movement[0] > 0:
            rect.right = tile.left
            collision_types["right"] = True
        elif movement[0] < 0:
            rect.left = tile.right
            collision_types["left"] = True
    rect.y += movement[1]

    # y movement

    hit_list = collision_test(rect, tiles)
    for tile in hit_list:
        if movement[1] > 0:
            rect.bottom = tile.top
            collision_types["bottom"] = True
        elif movement[1] < 0:
            rect.top = tile.bottom
            collision_types["top"] = True
    return rect, collision_types

def spawn_coin(x, y):
    if game_map[y][x] == "0":
        game_map[y][x] = "5"

def spawn_letter(letter, x, y):
    if game_map[y][x] == "0":
        game_map[y][x] = letter

def despawn_letters():
    y = 0
    for row in game_map:
        x = 0
        for tile in row:
            if tile.isalpha():
                game_map[y][x] = "0"
            x += 1
        y += 1

def pick_word():
    global word
    global definition
    global correct_letter
    global character_num

    with open("words_and_definitions.txt", 'r') as infile:
        lines = infile.readlines()

    word_data = [line.strip().split('|') for line in lines if line.strip()]
    idk = math.floor(len(word_data) / 10)
    # Pick a random word from the list
    random_word = word_data[random.randint(word_difficulty * idk - idk, word_difficulty * idk)]
    word, part_of_speech, definition = random_word

    spelling_dict.clear()

    for i in range(len(word)):
        spelling_dict[str(i)] = {"letter": word[i], "errors": 0, "collected": False}

    correct_letter = word[0]
    character_num = 0

    random.shuffle(valid_positions)

    for i in range(len(valid_positions)):
        if len(valid_positions) > 5:
            valid_positions.pop()

    for tuple in valid_positions:
        spawn_coin(tuple[1], tuple[0])

def get_valid_positions():
    y = 0
    for row in game_map:
        x = 0
        for tile in row:
            if tile == "1" or tile == "2" or tile == "3":
                if game_map[y - 1][x] == "0":
                    valid_positions.append((y - 1, x))
            x += 1
        y += 1

    standing_pos = (round(player_rect.y / tile_size + 1) - 1, round(player_rect.x / tile_size))

    # remove tuple where player is standing
    if standing_pos in valid_positions:
        valid_positions.remove(standing_pos)

def spawn_letters():
    global valid_positions
    global coin_counter
    valid_positions.clear()

    get_valid_positions()

    tuple = random.choice(valid_positions)
    valid_positions.remove(tuple)

    spawn_letter(correct_letter, tuple[1], tuple[0])

    for i in range(random.randint(1, 2)):
        tuple = random.choice(valid_positions)
        valid_positions.remove(tuple)

        random_letter = random.choice(string.ascii_lowercase)

        if random_letter != correct_letter:
            spawn_letter(random_letter, tuple[1], tuple[0])

def render_tiles():
    global coin_counter
    global correct_letter
    global character_num
    global words_spelt
    global elapsed_time

    y = 0
    for row in game_map:
        x = 0
        for tile in row:
            normal_tile_pos = (x * tile_size, y * tile_size)
            midbottom_pos = (x * tile_size + tile_size / 2, y * tile_size + tile_size)

            if tile == "1":
                # Dirt or Sand
                screen.blit(base_layer, normal_tile_pos) 
            if tile == "2":
                # Grass or Top sand
                screen.blit(ground_layer, normal_tile_pos)
            if tile == "3":
                # Platforms
                screen.blit(platform, normal_tile_pos)
            if tile == "4":
                # Obstacles
                obstacle_rect = obstacle.get_rect(midbottom = midbottom_pos)

                if not obstacle_rect in obstacle_rects:
                    obstacle_rects.append(obstacle_rect)

                if obstacle_rect.colliderect(player_rect):
                    bruh_sfx.play()
                    player_rect.midbottom = (default_location[0], default_location[1])

                screen.blit(obstacle, obstacle_rect)
            if tile == "5":
                # Coins
                coin_size = 4 * math.sin(pygame.time.get_ticks() / 100)

                coin_rect = coin.get_rect(midbottom = midbottom_pos)
                image_center = coin_rect.center

                size = tile_size / 2 + coin_size
                if not coin_rect in coin_rects:
                    coin_rects.append(coin_rect)

                if coin_rect.colliderect(player_rect):
                    spawn_particles(*coin_rect.center, 15, "yellow", (5, 5))
                    coin_counter += 1
                    coin_sfx.play()
                    coin_rects.remove(coin_rect)
                    game_map[y][x] = "0"

                updated_coin = pygame.transform.scale(coin, (size, size))
                screen.blit(updated_coin, updated_coin.get_rect(center = image_center))
            if tile != "0":
                if tile == "3":
                    tile_rects.append(pygame.Rect(x * tile_size, y * tile_size, tile_size, platform.get_height() * (tile_size / platform.get_width())))
                elif tile.isalpha():
                    # Letters
                    letter_text = letter_font.render(tile, False, (68, 74, 84))
                    letter_rect = letter_text.get_rect(midbottom = midbottom_pos)

                    pygame.draw.rect(screen, "grey95", letter_rect, 0, 8)

                    if not letter_rect in letter_rects:
                        letter_rects.append(letter_rect)

                    if letter_rect.colliderect(player_rect):
                        letter_rects.remove(letter_rect)
                        game_map[y][x] = "0"
                        if tile == correct_letter:
                            letter_sfx.play()

                            if character_num == len(word) - 1:
                                global word_difficulty
                                word_spelt_sfx.play()
                                words_spelt += 1

                                if not word_difficulty + 1 == 10:
                                    word_difficulty += 1
                                pick_word()
                                spawn_letters()
                            else:
                                spawn_particles(*letter_rect.midbottom, 15, "green", (5, 5))
                                character_num += 1
                                spelling_dict[str(character_num - 1)]["collected"] = True
                                correct_letter = word[character_num]
                                despawn_letters()
                                spawn_letters()
                        else:
                            elapsed_time += 5
                            spawn_particles(*letter_rect.midbottom, 10, "red", (4, 4))
                            spelling_dict[str(character_num)]["errors"] += 1
                            incorrect_sfx.play()

                    screen.blit(letter_text, letter_rect)
                elif tile != "5" and tile != "4":
                    # If tile isn't a coin or an obstacle, append tile to list.
                    tile_rects.append(pygame.Rect(x * tile_size, y * tile_size, tile_size, tile_size))
            x += 1
        y += 1

def get_font(size):
    return pygame.font.Font("fonts/vhs_gothic.ttf", size)

def blit_multiline_text(surface, text, font, color, rect):
    words = text.split(' ')
    lines = []
    current_line = ""

    for word in words:
        test_line = current_line + (f" {word}" if current_line else word)
        test_width, test_height = font.size(test_line)

        if test_width <= rect.width:
            current_line = test_line
        else:
            lines.append(current_line)
            current_line = word

    if current_line:
        lines.append(current_line)

    x, y = rect.topleft
    for line in lines:
        text_surface = font.render(line, True, color)
        if y + text_surface.get_height() > rect.bottom:
            break
        surface.blit(text_surface, (x, y))
        y += text_surface.get_height()

def render_word():
    for i in range(len(word)):
        letter = spelling_dict[str(i)]["letter"]
        errors = spelling_dict[str(i)]["errors"]
        collected = spelling_dict[str(i)]["collected"]
        colour = None

        if errors == 0:
            colour = "green"
        elif errors == 1:
            colour = "yellow"
        elif errors > 1:
            colour = "red"

        if not collected:
            colour = (68, 74, 84)

        letter_text = word_font.render(letter, False, colour)
        letter_rect = letter_text.get_rect(center = (i * 42 + WIDTH / 2 - (len(word) * 21 ), 50))
  
        if i == character_num:
            pygame.draw.rect(screen, "grey95", letter_rect, 0, 8)

        screen.blit(letter_text, letter_rect)
        blit_multiline_text(screen, definition, get_font(14), "grey25", pygame.rect.Rect(WIDTH / 2 - 200, 100, 400, 300))

def change_biome(biome):
    global ground_layer
    global base_layer
    global platform
    global obstacle

    if biome == 0:
        ground_layer = grass
        base_layer = dirt
        platform = grass_platform
        obstacle = spikes
    elif biome == 1:
        ground_layer = top_sand
        base_layer = sand
        platform = sand_platform
        obstacle = cactus

def randomize_map():
    global game_map

    game_map = maps[random.randint(0, len(maps) - 1)]

def start_game():
    global elapsed_time

    elapsed_time = 0
    tile_rects.clear()
    randomize_map()
    get_valid_positions()

    pick_word()
    spawn_letters()

    player_rect.midbottom = (default_location[0], default_location[1])

main_menu()

start_game()
change_biome(1)

